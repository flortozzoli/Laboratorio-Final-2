package ar.org.centro8.entities;

public class Auto extends Vehiculo {
    private int puerta;

    public Auto(String marca, String modelo, int puerta, double precio) {
        super(marca, modelo, precio);
        this.puerta = puerta;
    }

    @Override
    public String toString() {
        return "Marca: " + getMarca() + " // Modelo: " + getModelo() + " // Puertas: " + getPuerta() + " // Precio: $"
                + getPrecioFormat();

    }

    public int getPuerta() {
        return puerta;
    }

    public void setPuerta(int puerta) {
        this.puerta = puerta;
    }

}
