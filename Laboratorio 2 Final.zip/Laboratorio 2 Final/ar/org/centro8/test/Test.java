package ar.org.centro8.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.entities.Auto;
import ar.org.centro8.entities.Moto;
import ar.org.centro8.entities.Vehiculo;

public class Test {
    

    public static void main(String[] args) {
        List<Vehiculo> lista = new ArrayList<Vehiculo>();
            lista.add(new Auto("Peugeot", "206", 4, 200000));
            lista.add(new Moto("Honda", "Titan", "125c", 60000));
            lista.add(new Auto("Peugeot", "208", 5, 250000));
            lista.add(new Moto("Yamaha", "YBR", "160c", 80500.50));
    
            lista.forEach(System.out::println);
    

            System.out.println(" ");
            System.out.println("=============================");
            System.out.println(" ");
    
            /* VEHICULO MAS CARO */
            Vehiculo vehiculoCaro = lista
                    .stream()
                    .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                    .get();
            System.out.println("Vehículo mas caro: " + vehiculoCaro.getMarca() + " " + vehiculoCaro.getModelo());
    
            /*VEHICULO MAS BARATO*/
            Vehiculo vehiculoBarato = lista
                    .stream()
                    .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                    .get();
            System.out.println("Vehículo mas barato: " + vehiculoBarato.getMarca() + " " + vehiculoBarato.getModelo());
    
            /*
             * VEHICULO CON LETRA Y
             */
            lista
                    .stream()
                    .filter(p -> p.getMarca().toLowerCase().contains("y"))
                    .forEach(l -> System.out.println("Vehiculo que contiene en el modelo la letra 'Y': " + l.getMarca()
                            + " " + l.getModelo() + " " + l.getPrecio()));
    
            System.out.println(" ");
            System.out.println("=============================");
            System.out.println(" ");
    
            /*
             * ¨
             * ORDEN PRECIO DE MAYOR A MENOR
             */
            System.out.println("Vehículos ordenados por precio de mayor a menor:");
            lista
                    .stream()
                    .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                    .forEach(r -> System.out.println(r.getMarca() + " " + r.getModelo()));
    
            System.out.println(" ");
            System.out.println("=============================");
            System.out.println(" ");
    
            /*
             * ORDEN NATURAL
             */
            System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
            lista
                    .stream()
                    .sorted(Comparator.comparing(Vehiculo::getMarca))
                    .forEach(System.out::println);
    

    }

    

    }

